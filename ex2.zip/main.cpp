//
// hadar sabag id 312497126
//

#include <iostream>
#include "Game.h"

int main() {
    Game game;
    game.run();
    game.endingStatus();

}