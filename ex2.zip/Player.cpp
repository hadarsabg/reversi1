//
// hadar sabag id 312497126
//

#include "Player.h"

Player::Player(char symbol):symbol(symbol) {

};
Player::~Player() {};
char Player::getSymbol() const {
    return this->symbol;
}















